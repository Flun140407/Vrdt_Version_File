.. cmake-module:: ../../Modules/FindLATEX.cmake
