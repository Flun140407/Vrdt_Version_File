#include "clientsocketctrl.h"

TcpSocket::TcpSocket(QObject *parent)
    : QTcpSocket(parent)
{
    connect(this, SIGNAL(readyRead()), this, SLOT(receiveMessage()));
    connect(this, SIGNAL(disconnected()), this, SLOT(deleteScoket()));
    m_blockSize = 0;
    m_save.m_clientSocket = this;
}

TcpSocket::~TcpSocket()
{

}

void TcpSocket::receiveMessage()
{
    QDataStream in(this);
    in.setVersion(QDataStream::Qt_5_6);
    if (m_blockSize == 0)
    {
        if (bytesAvailable() < (int)sizeof(quint16))
            return;
        in >> m_blockSize;
    }

    if (bytesAvailable() < m_blockSize)
        return;

    in >> m_save.m_requestKind;

    switch (m_save.m_requestKind)
    {
    case SEND_File:
    {
        qDebug() << __FUNCTION__ << "SEND_File";

        m_blockSize = 0;
        in >> m_save.m_sendFileInfo;
        break;
    }
    case CONNECT_And_Get_System_Info:
    {
        qDebug() << __FUNCTION__ << "CONNECT_And_Get_System_Info";

        m_blockSize = 0;
        break;
    }
    }

    QByteArray data = this->readAll();
    qDebug() << __FUNCTION__ << "leaved in socket: " << data.size();

    m_blockSize =0;
    emit sendSignal(m_save);
}

void TcpSocket::sendMessage(const SaveTmpInformation &temp)
{
    QByteArray block;
    QDataStream out(&block, QIODevice::WriteOnly);
    out.setVersion(QDataStream::Qt_5_6);
    out << quint16(0) << (int)temp.m_replyKind;

    switch (temp.m_replyKind)
    {
    case SEND_File_OK:
    case SEND_File_Fail:
    {
        qDebug() << __FUNCTION__ << "SEND_File_OK";
        break;
    }
    case CONNECT_And_Get_System_Info_OK:
    {
        qDebug() << __FUNCTION__ << "CONNECT_And_Get_System_Info_OK";
        out << temp.m_systemInfo;
        break;
    }
    }

    out.device()->seek(0);
    out << quint16(block.size() - sizeof(quint16));
    write(block);
}
