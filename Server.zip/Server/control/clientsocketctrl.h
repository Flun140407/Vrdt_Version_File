#ifndef CLIENTSOCKETCTRL_H
#define CLIENTSOCKETCTRL_H
#include <QTcpSocket>
#include "model/constant.h"

class TcpSocket : public QTcpSocket
{

    Q_OBJECT
public:
    TcpSocket(QObject *parent = 0);
    ~TcpSocket();

signals:
    void sendSignal(const SaveTmpInformation &temp);

public slots:
    // 接收信息
    void receiveMessage();
    // 发送信息
    void sendMessage(const SaveTmpInformation &temp);

private:
    quint16 m_blockSize;
    SaveTmpInformation m_save;
};

#endif // CLIENTSOCKETCTRL_H
