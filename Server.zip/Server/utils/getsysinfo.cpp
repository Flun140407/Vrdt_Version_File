#include "getsysinfo.h"

#include "GetSysInfo.h"

//#define IPADDRESS 0
//#define VOLUME_AVALIBLE 1
//#define VOLUME_FREE 2
//#define VOLUME_TOTAL 3
//#define ROOT_PATH 4
//#define FREE_MEMORY_PERCENT 5
//#define VERSION 6
//#define CPU_INFO 7
//#define COMPUTER_MAC 8



SystemInformation GetSysInfo::GetSystemInformation()
{
    SystemInformation systemInfo;

    systemInfo.m_cpuType = cpuType();
    systemInfo.m_memory_usage = memory_usage();
    systemInfo.m_IP = GetIPS();
    systemInfo.m_MAC = get_MAC();
    systemInfo.m_allDiskInfo = GetAllDiskInfomation();
    return systemInfo;
}

AllDiskInfomation GetSysInfo::GetAllDiskInfomation()
{
    AllDiskInfomation allDiskInfo;

    QList<QStorageInfo> list = QStorageInfo::mountedVolumes();
    allDiskInfo.nDiskCount = list.size();
    for (const QStorageInfo& si : list)
    {
        SingleDiskInfomation singleDiskInfo;
        singleDiskInfo.m_rootPath = si.rootPath();
        singleDiskInfo.m_bytesTotal = si.bytesTotal()/1024/1024/1024;
        singleDiskInfo.m_bytesFree = si.bytesFree()/1024/1024/1024;
        singleDiskInfo.m_bytesAvailable = si.bytesAvailable()/1024/1024/1024;
        allDiskInfo.diskInformations.append(singleDiskInfo);
    }
    return allDiskInfo;
}

QString GetSysInfo::GetIPS()
{
    QList<QHostAddress> list = QNetworkInterface::allAddresses();
    foreach (QHostAddress address, list)
    {
        if(address.protocol() == QAbstractSocket::IPv4Protocol){

            QString str=address.toString();
            return str;
        }
    }
    return QString();
}
DWORD GetSysInfo::memory_usage()
{
    MEMORYSTATUS memorystatus;
    GlobalMemoryStatus(&memorystatus);
//    qDebug()<<memorystatus.dwAvailPageFile<<" "<<memorystatus.dwAvailPhys<<" "<<memorystatus.dwAvailVirtual<<" "<<memorystatus.dwLength
//           <<" "<<memorystatus.dwMemoryLoad<<" "<<memorystatus.dwTotalPhys;
    return memorystatus.dwMemoryLoad;
}


QStringList GetSysInfo::Volumn(QString volum)
{
    QStringList result;
    QList<QStorageInfo> list = QStorageInfo::mountedVolumes();
    qDebug() << "Volume Num: " << list.size();
    for(QStorageInfo& si : list)
    {

        if(si.rootPath()==volum)
        {
            result << QString::number(si.bytesAvailable()/1024/1024/1024);
            result << QString::number( si.bytesFree()/1024/1024/1024);
            result << QString::number( si.bytesTotal()/1024/1024/1024);
            result << si.rootPath();


        }
    }
    return result;
}


QString GetSysInfo::FindFile(const QString &strFilePath, const QString &strNameFilters)
{
    if (strFilePath.isEmpty() || strNameFilters.isEmpty())
    {
        return QString();
    }

    QDir dir;
    QStringList filters;
    QStringList result;
    filters << strNameFilters;
    dir.setPath(strFilePath);
    dir.setNameFilters(filters);
    QDirIterator iter(dir,QDirIterator::Subdirectories);

    //遍历出所有符合条件的文件
    while (iter.hasNext())
    {
        iter.next();
        QFileInfo info=iter.fileInfo();
        if (info.isFile())
        {
            result<<info.fileName();
        }
    }
    QString s1="";
    foreach(QString st, result)
    {
        if(s1.isEmpty())
        {
            s1=st;
            continue;
        }
        int value= s1.compare(st);
        if(value<0)
        {
            s1=st;
        }
    }
    return s1;
}

QString GetSysInfo::getServerinformation()
{//获取服务器全部信息
    QStringList result;
    result<<GetIPS();
    QStringList list=Volumn();
    result<<list;
    DWORD neicun=memory_usage();
    result<<QString::number(neicun);
    result<<FindFile(list[3]+"test/","*.txt");
    result<<cpuType();
    result<<get_MAC();

    QJsonObject jsonObj;
    jsonObj.insert("IPADRESS",result[0]);
    jsonObj.insert("VOLUME_AVALIBLE",result[1]);
    jsonObj.insert("VOLUME_FREE",result[2]);
    jsonObj.insert("VOLUME_TOTAL",result[3]);
    jsonObj.insert("ROOT_PATH",result[4]);
    jsonObj.insert("FREE_MEMORY_PERCENT",result[5]);
    jsonObj.insert("VERSION",result[6]);
    jsonObj.insert("CPU_INFO",result[7]);
    jsonObj.insert("COMPUTER_MAC",result[8]);



    return QString(QJsonDocument(jsonObj).toJson(QJsonDocument::Compact));;
}


QString GetSysInfo::cpuType()
{
    QSettings *CPU = new QSettings("HKEY_LOCAL_MACHINE\\HARDWARE\\DESCRIPTION\\System\\CentralProcessor\\0",QSettings::NativeFormat);
    QString cpuDescribe = CPU->value("ProcessorNameString").toString();
    delete CPU;

    return cpuDescribe;
}

QString GetSysInfo::get_MAC()
{
    QList<QNetworkInterface> nets = QNetworkInterface::allInterfaces();// 获取所有网络接口列表
    int nCnt = nets.count();
    QString strMacAddr = "";
    for(int i = 0; i < nCnt; i ++)
    {
        // 如果此网络接口被激活并且正在运行并且不是回环地址，则就是我们需要找的Mac地址
        if(nets[i].flags().testFlag(QNetworkInterface::IsUp) && nets[i].flags().testFlag(QNetworkInterface::IsRunning)
                && !nets[i].flags().testFlag(QNetworkInterface::IsLoopBack))
        {
            strMacAddr = nets[i].hardwareAddress();
            break;
        }
    }
    return strMacAddr;
}

QString GetSysInfo::getSimInfo()
{//获取服务器简单信息
    QStringList result;
    result<<GetIPS();
    QStringList list=Volumn();
    result<<FindFile(list[3]+"test/","*.txt");
    result<<get_MAC();

    QJsonObject jsonObj;
    jsonObj.insert("IPADRESS",result[0]);
    jsonObj.insert("VERSION",result[1]);
    jsonObj.insert("COMPUTER_MAC",result[2]);

    return QString(QJsonDocument(jsonObj).toJson(QJsonDocument::Compact));;
}




























