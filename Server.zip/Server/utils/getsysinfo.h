#pragma once

#include <QWidget>
#include <windows.h>
#include <QStorageInfo>
#include "QtNetwork/QNetworkInterface"
#include <QSettings>
#include "QDirIterator"
#include <QJsonObject>
#include <QJsonDocument>
#include "model/constant.h"

class GetSysInfo
{

public:
    static SystemInformation GetSystemInformation();

    static AllDiskInfomation GetAllDiskInfomation();

   static QString GetIPS();
   static DWORD memory_usage();
   static QStringList Volumn(QString volum="C:/");
   static QString FindFile(const QString &strFilePath, const QString &strNameFilters);//返回版本号
   static QString getServerinformation();
   static QString cpuType();
   static QString get_MAC();
   static QString getSimInfo();
};

