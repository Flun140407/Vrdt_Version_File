#ifndef CONSTANT_H
#define CONSTANT_H

#include <QList>
#include <QFont>
#include <QColor>
#include <QDataStream>
#include <QDateTime>
#include <QVector>
#include <QString>
#include <QObject>

class TcpSocket;

static const int nPort = 6000;

// 信息类型
enum MessageType
{
    REGISTER,                   // 注册
    REGISTER_OK,
    REGISTER_Fail,

    LOGIN,                      // 登录
    LOGIN_OK,
    LOGIN_Fail,

    CONNECT_And_Get_System_Info,//连接并获取系统信息
    CONNECT_And_Get_System_Info_OK,
    CONNECT_And_Get_System_Info_Fail,

    SEND_File,                  // 发送文件
    SEND_File_OK,
    SEND_File_Fail,
};

// 用户详细信息
struct UserInformation
{
    QString m_name;

    friend QDataStream &operator<<(QDataStream &out, const UserInformation &user)
    {
       out << user.m_name;
       return out;
    }

    friend QDataStream &operator>>(QDataStream &in, UserInformation &user)
    {
       in >> user.m_name;
       return in;
    }
};

// 发送文件信息
struct SendFileInformation
{
    QString m_filepath;//文件路径
    QString m_filename;//文件名
    QByteArray m_bytearray;

    friend QDataStream &operator<<(QDataStream &out, const SendFileInformation &user)
    {
       out << user.m_filepath << user.m_filename << user.m_bytearray;
       return out;
    }

    friend QDataStream &operator>>(QDataStream &in, SendFileInformation &user)
    {
       in >> user.m_filepath >> user.m_filename >> user.m_bytearray;
       return in;
    }
};

// 单个硬盘信息
struct SingleDiskInfomation
{
    QString m_rootPath;
    int m_bytesTotal;
    int m_bytesFree;
    int m_bytesAvailable;

    friend QDataStream &operator<<(QDataStream &out, const SingleDiskInfomation &user)
    {
       out << user.m_rootPath << user.m_bytesTotal << user.m_bytesFree << user.m_bytesAvailable;
       return out;
    }

    friend QDataStream &operator>>(QDataStream &in, SingleDiskInfomation &user)
    {
       in >> user.m_rootPath >> user.m_bytesTotal >> user.m_bytesFree >> user.m_bytesAvailable;
       return in;
    }
};

struct AllDiskInfomation
{
    int nDiskCount;
    QList<SingleDiskInfomation> diskInformations;

    friend QDataStream &operator<<(QDataStream &out, const AllDiskInfomation &user)
    {
        out << user.nDiskCount;
        for (int i=0; i<user.nDiskCount; i++)
        {
            out << user.diskInformations[i];
        }
        return out;
    }

    friend QDataStream &operator>>(QDataStream &in, AllDiskInfomation &user)
    {
        user.diskInformations.clear();
        in >> user.nDiskCount;
        for (int i=0; i<user.nDiskCount; i++)
        {
            SingleDiskInfomation tmp;
            in >> tmp;
            user.diskInformations.append(tmp);
        }
        return in;
    }
};
Q_DECLARE_METATYPE(AllDiskInfomation)

// 系统信息
struct SystemInformation
{
    QString m_cpuType;
    int m_memory_usage;
    QString m_IP;
    QString m_MAC;
    AllDiskInfomation m_allDiskInfo;

    friend QDataStream &operator<<(QDataStream &out, const SystemInformation &user)
    {
       out << user.m_cpuType << user.m_IP << user.m_memory_usage << user.m_MAC << user.m_allDiskInfo;
       return out;
    }

    friend QDataStream &operator>>(QDataStream &in, SystemInformation &user)
    {
       in >> user.m_cpuType >> user.m_IP >> user.m_memory_usage >> user.m_MAC >> user.m_allDiskInfo;
       return in;
    }
};
Q_DECLARE_METATYPE(SystemInformation)

// 存储临时信息的结构体，用于信号/糟
struct SaveTmpInformation
{
    int m_requestKind;
    int m_replyKind;
    TcpSocket *m_clientSocket;

    UserInformation m_userInf;
    SendFileInformation m_sendFileInfo;
    SystemInformation m_systemInfo;
};

#endif // CONSTANT_H
