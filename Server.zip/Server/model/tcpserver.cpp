#include "tcpserver.h"

TcpServer::TcpServer(QObject *parent)
    : QTcpServer(parent)
{

}

TcpServer::~TcpServer()
{

}

QString tempSysInfo()
{
    return "win10";
}

QString tempDir()
{
    return "C:/TMP_TMP/";
}

void TcpServer::sendMessage(const SaveTmpInformation &save)
{
    switch (save.m_requestKind)
    {
    case CONNECT_And_Get_System_Info:
    {
        qDebug() << __FUNCTION__ << "CONNECT_And_Get_System_Info";
        m_save.m_systemInfo = GetSysInfo::GetSystemInformation();
        m_save.m_replyKind = CONNECT_And_Get_System_Info_OK;
        save.m_clientSocket->sendMessage(m_save);
        break;
    }
    case SEND_File:
    {
        qDebug() << __FUNCTION__ << "SEND_File";
        m_save.m_sendFileInfo = save.m_sendFileInfo;

        /************* 获取文件名，保存文件，更新响应类型 *****************/
        QString filename = m_save.m_sendFileInfo.m_filename;
        QByteArray bytearray = m_save.m_sendFileInfo.m_bytearray;
        QFile file(tempDir() + filename); // "C:/TMP_TMP/xxx.h";
        if (!file.open(QIODevice::WriteOnly))
        {
            qDebug() << __FUNCTION__ << __LINE__;
            m_save.m_replyKind = SEND_File_Fail;
        }
        else {
            qDebug() << __FUNCTION__ << __LINE__;
            file.write(bytearray);
            m_save.m_replyKind = SEND_File_OK;
        }
        /************* 获取文件名，保存文件，更新响应类型 *****************/

        save.m_clientSocket->sendMessage(m_save);
        break;
    }
    default:
        break;
    }
}

void TcpServer::incomingConnection(qintptr socketDescriptor)
{
    TcpSocket *clientSocket = new TcpSocket(this);
    clientSocket->setSocketDescriptor(socketDescriptor);
    //connect(clientSocket, SIGNAL(deleteSignal(const QString &)),
     //   this, SLOT(clientDisconnected(const QString &)));
    connect(clientSocket, SIGNAL(sendSignal(const SaveTmpInformation &)),
        this, SLOT(sendMessage(const SaveTmpInformation &)));

    qDebug() <<"new client IP:" << clientSocket->peerAddress();
}
