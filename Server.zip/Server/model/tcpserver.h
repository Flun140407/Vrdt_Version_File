#ifndef TCPSERVER_H
#define TCPSERVER_H
#include <QTcpServer>
#include <QFile>
#include "control/clientSocketCtrl.h"
#include "constant.h"
#include "utils/getsysinfo.h"

class TcpServer : public QTcpServer
{
    Q_OBJECT
public:
    TcpServer(QObject *parent = 0);
    ~TcpServer();

public slots:
    // 客户端断开连接
    //void clientDisconnected(const QString &id);
    // 要求clientSocket发送信息
    void sendMessage(const SaveTmpInformation &save);

private:
    // 当有新的连接时，会调用此函数。用于创建新的线程去控制socket通信
    virtual void incomingConnection(qintptr socketDescriptor);

private:
    // 临时信息
    SaveTmpInformation m_save;
};

#endif // TCPSERVER_H
