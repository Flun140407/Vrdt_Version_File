#include "widget.h"
#include "model/tcpserver.h"
#include "utils/getsysinfo.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    qRegisterMetaType<AllDiskInfomation>();
    qRegisterMetaTypeStreamOperators<AllDiskInfomation>("AllDiskInfomation");

    qRegisterMetaType<SystemInformation>();
    qRegisterMetaTypeStreamOperators<SystemInformation>("SystemInformation");

    QApplication a(argc, argv);
    Widget w;
    w.show();

    TcpServer* server = new TcpServer;
    bool bok = server->listen(QHostAddress::Any, nPort);

//    qDebug() << "cpuType" << GetSysInfo::cpuType();
//    qDebug() << "GetIPS" << GetSysInfo::GetIPS();
//    //qDebug() << GetSysInfo::getServerinformation();
//    qDebug() << "getSimInfo" << GetSysInfo::getSimInfo();
//    qDebug() << "get_MAC" << GetSysInfo::get_MAC();
//    qDebug() << "memory_usage" << GetSysInfo::memory_usage();
//    qDebug() << "Volumn" << GetSysInfo::Volumn();

    return a.exec();
}
